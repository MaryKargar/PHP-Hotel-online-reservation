<?php
	require_once 'connect.php';
	// If the information is posted by clicking the edit_account button for this file
	if(ISSET($_POST['edit_account'])){
		// get posted data
		$name = $_POST['name'];
		$username = $_POST['username'];
		$password = $_POST['password'];
		// run an update query for edit user information in admin table
		$conn->query("UPDATE `admin` SET `name` = '$name', `username` = '$username', `password` = '$password' WHERE `admin_id` = '$_REQUEST[admin_id]'") or die(mysqli_error());
		// go to account.php
		header("location:account.php");
	}	