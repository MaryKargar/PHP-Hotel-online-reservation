<?php
	// If the information is posted by clicking the add_account button for this file
	if(ISSET($_POST['add_account'])){
		// get posted data
		$name = $_POST['name'];
		$username = $_POST['username'];
		$password = $_POST['password'];
		// check user exist. if exist, return user data
		$query = $conn->query("SELECT * FROM `admin` WHERE `username` = '$username'") or die(mysqli_error());
		// count number of uesr with this information. It must be zero, otherwise there is a user
		$valid = $conn->num_rows;
		// if not zero. show a message. user exist
		if($valid > 0){
			echo "<center><label style = 'color:red;'>Diese Benutzer Name exestiert</center></label>";
		}else{
			// save user information in admin table
			$conn->query("INSERT INTO `admin` (name, username, password) VALUES('$name', '$username', '$password')") or die(mysqli_error());
			// go to account.php
			header("location:account.php");
		}
	}
?>
