<?php
	// connect to database
	require_once 'connect.php';
	//  recieve id with Get method (with $_REQUEST)
	// search room with id and delete it from admin table
		$conn->query("DELETE FROM `room` WHERE `room_id` = '$_REQUEST[room_id]'") or die(mysqli_error());
		//  goto delete.php
	header("location:room.php");
?>