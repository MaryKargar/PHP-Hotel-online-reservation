<?php
	require_once 'connect.php';
	//  recieve id with Get method (with $_REQUEST)
	// search reserve with id and delete it from transaction table
	$conn->query("DELETE FROM `transaction` WHERE `transaction_id` = '$_REQUEST[transaction_id]'") or die(mysqli_error());
	header("location:reserve.php");
?>