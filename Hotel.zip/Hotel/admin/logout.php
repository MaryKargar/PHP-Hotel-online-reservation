<?php
	
	session_start();
	// unset session for remove user id
	session_unset(admin_id);
	// open index page
	header("location:index.php");
?>