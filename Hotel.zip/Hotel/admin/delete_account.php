<?php
	// connect to database
	 require_once 'connect.php';
	//  recieve id with Get method (with $_REQUEST)
	// search user with id and delete it from admin table
	 $conn->query("DELETE FROM `admin` WHERE `admin_id` = '$_REQUEST[admin_id]'") or die(mysqli_error());
	//  goto account.php
	 header("location: account.php");