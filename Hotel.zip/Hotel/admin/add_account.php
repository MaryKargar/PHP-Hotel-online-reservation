<!DOCTYPE html>
<?php
	require_once 'validate.php';
	require 'name.php';
?>
<html lang = "en">
	<head>
		<title>Online Reservation Hotel</title>
		<meta charset = "utf-8" />
		<meta name = "viewport" content = "width=device-width, initial-scale=1.0" />
		<link rel = "stylesheet" type = "text/css" href = "../css/bootstrap.css " />
		<link rel = "stylesheet" type = "text/css" href = "../css/style.css" />
		<link rel="stylesheet" type="text/css" href="../css/mystyle.css">
	</head>
<body>
	<nav style = "background-color:rgba(0, 0, 0, 0.1);" class = "navbar navbar-default">
		<div  class = "container-fluid">
			<div class = "navbar-header" style ="margin-left:550px">
				<a class = "navbar-brand" style="font-family: 'Amin';font-size: 25px;" >Online Reservation Hotel</a>
			</div>
			<ul class = "nav navbar-nav pull-right ">
				<li class = "dropdown">
					<a class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> <?php echo $name;?></a>
					<ul class="dropdown-menu">
						<li><a href="logout.php"> Logout</a></li>
					</ul>
				</li>
			</ul>
		</div>
	</nav>
	<div class = "container-fluid" >
		<div class="row">
		<div class="col-md-3"></div>

		<div class="col-md-6">
			<ul class = "nav nav-pills" style="font-family: 'Amin';font-size: 18px;" >
			
				<li ><a href = "../index.php">Erste Seite</a></li>	
				<li class = "active"><a href = "account.php">Benutzer konto</a></li>
				<li><a href = "room.php">Zimmer verwaltung</a></li>
				<li><a href = "reserve.php">Reservation</a></li>
						
						
			</ul>

		
		</div>

		<div class="col-md-3"></div>
		
		</div>
		
	</div>
	<br />
	<br />
	<!-- create main content box -->
	<div class = "container-fluid" dir="ltr" style="font-family: 'Amin'">
		<div class = "panel panel-default">
			<div class = "panel-body">
			<!-- title in blue box -->
				<div class = "alert alert-info">Benutzer kontos / add neue Benutzer konto</div>
				<br />
				<div class = "col-md-4" style = "margin-left:400px;">
				<!-- start form  -->
					<form method = "POST">
						<div class = "form-group">
							<label>Vorname und Nachname </label>
							<input type = "text" class = "form-control" name = "name" />
						</div>
						<div class = "form-group">
							<label>Benutzer name</label>
							<input type = "text" class = "form-control" name = "username" />
						</div>
						<div class = "form-group">
							<label>Kennwort </label>
							<input type = "password" class = "form-control" name = "password" />
						</div>
						<br />
						<div class = "form-group">
						<!-- when click this button form data post for add_query_account.php -->
							<button name = "add_account" class = "btn btn-info form-control"> Spichern </button>
						</div>
					</form>
					<!-- end form -->
					<!-- attach add_query_account.php -->
					<?php require_once 'add_query_account.php'?>
				</div>
			</div>
		</div>
	</div>
	<br />
	<br />
	<div style = "text-align:left; margin-right:10px;" class = "navbar navbar-default navbar-fixed-bottom">
		<label> </label>
	</div>
</body>
<script src = "../js/jquery.js"></script>
<script src = "../js/bootstrap.js"></script>
</html>

