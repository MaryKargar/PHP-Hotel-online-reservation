<!DOCTYPE html>
<?php
	require_once 'validate.php';
	require 'name.php';

?>
<html lang = "en">
	<head>
		<title>Online Reservation Hotel</title>
		<meta charset = "utf-8" />
		<meta name = "viewport" content = "width=device-width, initial-scale=1.0" />
		<link rel = "stylesheet" type = "text/css" href = "../css/bootstrap.css " />
		<link rel = "stylesheet" type = "text/css" href = "../css/style.css" />
		<link rel="stylesheet" type="text/css" href="../css/mystyle.css">
	</head>
<body>
	<nav style = "background-color:rgba(0, 0, 0, 0.1);" class = "navbar navbar-default">
		<div  class = "container-fluid">
			<div class = "navbar-header" style ="margin-left:550px">
				<a class = "navbar-brand" style="font-family: 'Amin';font-size: 25px;" >Online Reservation Hotel</a>
			</div>
			<ul class = "nav navbar-nav pull-right ">
				<li class = "dropdown">
					<a class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> <?php echo $name;?></a>
					<ul class="dropdown-menu">
						<li><a href="logout.php"> Logout</a></li>
					</ul>
				</li>
			</ul>
		</div>
	</nav>
	<div class = "container-fluid" >
		<div class="row">
		<div class="col-md-3"></div>

		<div class="col-md-6">
			<ul class = "nav nav-pills" style="font-family: 'Amin';font-size: 18px;" >
			
				<li> <a href = "../index.php">Erste Seite</a></li>	
				<li><a href = "account.php">Benutzer konto</a></li>
				<li><a href = "room.php">Zimmer verwaltung</a></li>
				<li class = "active"><a href = "reserve.php">Reservation</a></li>
						
						
			</ul>

		
		</div>

		<div class="col-md-3"></div>
		
		</div>
		
	</div>
	<br />
	<br />
	<div class = "container-fluid" dir="ltr" style="font-family: 'Amin'">
		<div class = "panel panel-default">
			<?php
				// Counts the number of reservations whose status is pending in the database (transaction table)
				$q_p = $conn->query("SELECT COUNT(*) as total FROM `transaction` WHERE `status` = 'Pending'") or die(mysqli_error());
				$f_p = $q_p->fetch_array();
				// Counts the number of reservations whose status is 'Check In' in the database (transaction table)
				$q_ci = $conn->query("SELECT COUNT(*) as total FROM `transaction` WHERE `status` = 'Check In'") or die(mysqli_error());
				$f_ci = $q_ci->fetch_array();
			?>
			<div class = "panel-body">
				<!-- show number of  reservations whose status is pending in a  badge. this button is disabled-->
				<a class = "btn btn-success disabled"><span class = "badge"><?php echo $f_p['total']?></span> in warte liste</a>
				<!-- show number of  reservations whose status is 'Check In' in a  badge-->
				<!-- when click this button go to checkin.php -->
				<a class = "btn btn-info" href = "checkin.php"><span class = "badge"><?php echo $f_ci['total']?></span> Zulassung liste</a>
				<!-- when click this button go to checkout.php -->
				<a class = "btn btn-warning" href = "checkout.php"> zahlung liste</a>
				<br />
				<br />
				<table id = "table" class = "table table-bordered">
					<thead>
						<tr>
						<!-- table header -->
							<th style="text-align:center">Vorname un Nachname</th>
							<th style="text-align:center">Tel </th>
							<th style="text-align:center">Zimmer Type</th>
							<th style="text-align:center">Reserv Datum</th>
							<th style="text-align:center">Status</th>
							<th style="text-align:center">Operation</th>
						</tr>
					</thead>
					<tbody align="center">
						<?php
							// The information of two transaction and guest tables is combined and displayed in one table (transactions whose status is pending).
							$query = $conn->query("SELECT * FROM `transaction` NATURAL JOIN `guest` NATURAL JOIN `room` WHERE `status` = 'Pending'") or die(mysqli_error());
							// The list of data returns as an array. So we iterate the array and put each one in a table row

							while($fetch = $query->fetch_array()){
						?>
						<!--  At each loop, a guest's and reserve information is placed inside a row of tables -->
						<!-- start row -->
						<tr>
							<td><?php echo $fetch['firstname']." ".$fetch['lastname']?></td>
							<td><?php echo $fetch['contactno']?></td>
							<td><?php echo $fetch['room_type']?></td>
							<td>
                                <strong>
                                    <?php

									// get today date

                                    $solar_date = new DateTime();

									// if Date of arrival is less than today date, show it with red color else sohw it with  green color

                                       if($fetch['checkin'] <= $solar_date)
                                        {
                                            echo "<label style = 'color:#ff0000;'>".$fetch['checkin']."</label>";
                                        }else
                                            {
                                                echo "<label style = 'color:#00ff00;'>".$fetch['checkin']."</label>";
                                            }
                                       ?>
                                </strong></td>
							<td><?php echo $fetch['status']?></td>
							<td><center>
							<!-- if click this button go to confirm_reserve.php and send transaction id for it -->
							<a class = "btn btn-success" href = "confirm_reserve.php?transaction_id=<?php echo $fetch['transaction_id']?>"> Buchen</a> 
							<!-- when click delete button  call an javascript function (confirmationDelete) As defined in line 152 -->
							<a class = "btn btn-danger" onclick = "confirmationDelete(); return false;" href = "delete_pending.php?transaction_id=<?php echo $fetch['transaction_id']?>"> Stonieren</a></td>
						</tr>
						<?php
							}
						?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
	<br />
	<br />
	<div style = "text-align:left; margin-right:10px;" class = "navbar navbar-default navbar-fixed-bottom">
		<label></label>
	</div>
</body>
<script src = "../js/jquery.js"></script>
<script src = "../js/bootstrap.js"></script>
<script src = "../js/jquery.dataTables.js"></script>
<script src = "../js/dataTables.bootstrap.js"></script>
<script type = "text/javascript">
	$(document).ready(function(){
		$("#table").DataTable();
	});
</script>
<script type = "text/javascript">
// show an alert box Which gets the deletion confirmation from the user
	function confirmationDelete(anchor){
		var conf = confirm("Wollen sie löschen?");
		// If the OK button is clicked. The <a> tage href run and go to delete_pending.php And the user ID is sent for it
		if(conf){
			window.location = anchor.attr("href");
		}
	}
</script>
</html>


