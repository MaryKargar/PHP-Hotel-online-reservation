<?php
	// connect to mkagar database with user and password in mysql
	$conn = new mysqli("localhost", "mkargar", "2640014481mK", "mkargar") or die(mysqli_error());
	// $conn = new mysqli("localhost", "root", "", "db_hor") or die(mysqli_error());
?>