<!DOCTYPE html>
<?php
	require_once 'validate.php';
	require 'name.php';
?>
<html lang = "en">
	<head>
		<title>Online Reservation Hotel</title>
		<meta charset = "utf-8" />
		<meta name = "viewport" content = "width=device-width, initial-scale=1.0" />
		<link rel = "stylesheet" type = "text/css" href = "../css/bootstrap.css " />
		<link rel = "stylesheet" type = "text/css" href = "../css/style.css" />
		<link rel="stylesheet" type="text/css" href="../css/mystyle.css">
	</head>
<body>
	<nav style = "background-color:rgba(0, 0, 0, 0.1);" class = "navbar navbar-default">
		<div  class = "container-fluid">
			<div class = "navbar-header" >
				<a class = "navbar-brand" style="font-family: 'Amin';font-size: 25px;" >Online Reservation Hotel</a>
			</div>
			<ul class = "nav navbar-nav pull-right ">
				<li class = "dropdown">
					<a class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> <?php echo $name;?></a>
					<ul class="dropdown-menu">
						<li><a href="logout.php"> Logout</a></li>
					</ul>
				</li>
			</ul>
		</div>
	</nav>
	<div class = "container-fluid" >
		<div class="row">
		<div class="col-md-3"></div>

		<div class="col-md-6">
			<ul class = "nav nav-pills" style="font-family: 'Amin';font-size: 18px;" >
			
				<li><a href = "../index.php">Erste Seite</a></li>	
				<li><a href = "account.php">Benutzer konto</a></li>
				<li><a href = "room.php">Zimmer verwaltung</a></li>
				<li class = "active"><a href = "reserve.php">Reservation</a></li>
						
			</ul>

		
		</div>

		<div class="col-md-3"></div>
		
		</div>
		
	</div>
	<br />
	<br />
	<div class = "container-fluid" dir="ltr" style="font-family: 'Amin'">
		<div class = "panel panel-default">
			<div class = "panel-body" >
				<div class = "alert alert-info">kompletet anmeldung Prosess</div>
				
				<?php
				//  recieve id with Get method (with $_REQUEST)
				// The information of three table is combined (transaction and guest and room) and displayed in form.

					$query = $conn->query("SELECT * FROM `transaction` NATURAL JOIN `guest` NATURAL JOIN `room` WHERE `transaction_id` = '$_REQUEST[transaction_id]'") or die(mysqli_error());
					$fetch = $query->fetch_array();
				?>
				<br />
				<div class="container-fluid">
				<form method = "POST" enctype = "multipart/form-data" action = "save_form.php?transaction_id=<?php echo $fetch['transaction_id']?>">

				<!-- <br /> -->
						<!-- <input type = "text" value = "<?php echo $fetch['middlename']?>" class = "form-control" size = "40" disabled = "disabled"/> -->
					<div class="row">
						<div class="col-md-4">
							<div class = "form-inline" style = "float:left; ">
								<label>Nachname</label>
								<br />
								<input type = "text" value = "<?php echo $fetch['lastname']?>" class = "form-control" size = "40" disabled = "disabled"/>
							</div>
						</div>
					
						<div class="col-md-6">
							<div class = "form-inline" style = "float:left;">
								<label>Vorname</label>
								<br />
								<!-- We disabled personal information input so that it could not be changed (disabled = "disabled"/). -->

								<input type = "text" value = "<?php echo $fetch['firstname']?>" class = "form-control" size = "40" disabled = "disabled"/>
							</div>
						</div>
					</div>

					<div class="row"><div class="col-12"><br><br></div></div>

					<div class="row">
						<div class="col-md-2">
							<div class = "form-inline" style = "float:left;">
								<label>Zimmer Type</label>
								<br />
								<!-- We disabled room information input so that it could not be changed (disabled = "disabled"/). -->

								<input type = "text" value = "<?php echo $fetch['room_type']?>" class = "form-control" size = "20" disabled = "disabled"/>
							</div>
						</div>
						<div class="col-md-8">

								
							<div class = "form-inline" style = "float:left; margin-left:20px;">
								<label>Zimmer nummer</label>
								<br />
								<input type = "number" min = "0" max = "999" name = "room_no" class = "form-control" required = "required"/>
							</div>
							<div class = "form-inline" style = "float:left; margin-left:20px;">
								<label>Tag</label>
								<br />

								<?php
								// The date of arrival and departure of the string. We turn them into time
								$date1 = strtotime($fetch['checkout']);
								$date2 = strtotime($fetch['checkin']);

								?>
								<!-- Using the date of arrival and departure, we calculate the number of days of stay (Abs is an absolute value) -->
								<input type = "text" value="<?php echo $hourDiff=round(abs($date1 - $date2) / (60*60*24),0);   ?>" name = "days" class = "form-control" required = "required" />
							</div>
							<div class = "form-inline" style = "float:left; margin-left:20px;">
								<label>Exstra bett</label>
								<br />
								<input type = "number" min = "0" max = "99" name = "extra_bed" class = "form-control"/>
							</div>
							<div class = "form-inline" style = "float:left; margin-left:20px;">
								<label style = "color:#ff0000; margin-top:30px">Extra bett mit 50 EUR </label>
							</div>

						</div>
					</div>

					<div class="row"><div class="col-12"><br><br></div></div>

					<div class="row">
						<div class="col-md-4"></div>
						<div class="col-md-4">
						<!-- if click this button go to save_form.php and send transaction id for it -->

							<button name = "add_form" class = "btn btn-primary" >Spichern</button>
						</div>

						<div class="col-md-4"></div>
					</div>

				</div>

				</form>
			</div>
		</div>
	</div>
	<br />
	<br />
	<div style = "text-align:right; margin-right:10px;" class = "navbar navbar-default navbar-fixed-bottom">
		<label></label>
	</div>
</body>
<script src = "../js/jquery.js"></script>
<script src = "../js/bootstrap.js"></script>
</html>

