<?php
// connect to database and get user data. search it by id that saved in session
	require 'connect.php';
	$query = $conn->query("SELECT * FROM `admin` WHERE `admin_id` = '$_SESSION[admin_id]'") or die(mysqli_error());
	$fetch = $query->fetch_array();
	// save user name in a varriable
	$name = $fetch['name'];
?>