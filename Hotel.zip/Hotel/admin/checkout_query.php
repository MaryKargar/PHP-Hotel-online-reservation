<?php
	require_once 'connect.php';
	// get today date
    date_default_timezone_set("Europe/Vienna");
    $time = date("H:i:s", strtotime("+24 HOURS"));
	// register today date for checkout reserve and change status to Check Out(find reserve with transaction id)
	$conn->query("UPDATE `transaction` SET `checkout_time` = '$time', `status` = 'Check Out' WHERE `transaction_id` = '$_REQUEST[transaction_id]'") or die(mysqli_error());
	header("location:checkout.php");
?>