<!DOCTYPE html>
<?php
	require_once 'validate.php';
	require 'name.php';
?>
<html lang = "en">
	<head>
		<title>Online Reservation Hotel</title>
		<meta charset = "utf-8" />
		<meta name = "viewport" content = "width=device-width, initial-scale=1.0" />
		<link rel = "stylesheet" type = "text/css" href = "../css/bootstrap.css " />
		<link rel = "stylesheet" type = "text/css" href = "../css/style.css" />
		<link rel="stylesheet" type="text/css" href="../css/mystyle.css">
	</head>
<body>
	<nav style = "background-color:rgba(0, 0, 0, 0.1);" class = "navbar navbar-default">
		<div  class = "container-fluid">
			<div class = "navbar-header" style ="margin-left:550px">
				<a class = "navbar-brand" style="font-family: 'Amin';font-size: 25px;" >Online Reservation Hotel</a>
			</div>
			<ul class = "nav navbar-nav pull-right ">
				<li class = "dropdown">
					<a class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> <?php echo $name;?></a>
					<ul class="dropdown-menu">
						<li><a href="logout.php"> Logout</a></li>
					</ul>
				</li>
			</ul>
		</div>
	</nav>
	<div class = "container-fluid" >
		<div class="row">
		<div class="col-md-3"></div>

		<div class="col-md-6">
			<ul class = "nav nav-pills" style="font-family: 'Amin';font-size: 18px;" >
			
				<li ><a href = "../index.php">Erste Seite</a></li>	
				<li><a href = "account.php">Benutzer konto</a></li>
				<li><a href = "room.php">Zimmer verwaltung</a></li>
				<li class = "active"><a href = "reserve.php">Reservation</a></li>
						
			</ul>

		
		</div>

		<div class="col-md-3"></div>
		
		</div>
		
	</div>
	<br />
	<br />
	<div class = "container-fluid" dir="ltr" style="font-family: 'Amin'">
		<div class = "panel panel-default">
			<?php
				$q_p = $conn->query("SELECT COUNT(*) as total FROM `transaction` WHERE `status` = 'Pending'") or die(mysqli_error());
				$f_p = $q_p->fetch_array();
				$q_ci = $conn->query("SELECT COUNT(*) as total FROM `transaction` WHERE `status` = 'Check In'") or die(mysqli_error());
				$f_ci = $q_ci->fetch_array();
			?>
			<div class = "panel-body">
				<a class = "btn btn-success" href = "reserve.php"><span class = "badge"><?php echo $f_p['total']?></span> In warte List</a>
				<a class = "btn btn-info" href = "checkin.php"><span class = "badge"><?php echo $f_ci['total']?></span> zulassung list</a>
				<a class = "btn btn-warning disabled"> Zahlung list</a>
				<br />
				<br />
				<table id = "table" class = "table table-bordered">
					<thead align="center">
						<tr>
						<th style="text-align:center">Vorname und Nachname</th>
							<th style="text-align:center">Zimmer Type</th>
							<th style="text-align:center">Zimmer Nummer</th>
							<th style="text-align:center">chec</th>
							<th style="text-align:center">Tag</th>
							<th style="text-align:center">checkout</th>
							<th style="text-align:center">status</th>
							<th style="text-align:center">Extra bett</th>
							<th style="text-align:center">Gesamte Zahlung</th>
							<th></th>
						</tr>
					</thead>
					<tbody align="center">
						<?php
                        // date_default_timezone_set("Europe/Vienna");
                        // $time = date("H:i:s", strtotime("+24 HOURS"));

						// The information of three table (transaction, guest, room) and data is combined and displayed in one table (transactions whose status is checkout).

							$query = $conn->query("SELECT * FROM `transaction` NATURAL JOIN `guest` NATURAL JOIN `room` WHERE `status` = 'Check Out'") or die(mysqli_query());
							while($fetch = $query->fetch_array()){
								
						?>
						<!--  At each loop,  guest and reserve and transaction information is placed inside a row of tables -->
						<!-- start row -->
						<tr>
							<td><?php echo $fetch['firstname']." ".$fetch['lastname']?></td>
							<td><?php echo $fetch['room_type']?></td>
							<td><?php echo $fetch['room_no']?></td>
							<td><?php echo "<label style = 'color:#00ff00;'>".$fetch['checkin']."</label>"." Uhrzeit "."<label>".date("h:i A", strtotime($fetch['checkin_time']))."</label>"?></td>
							<td><?php echo $fetch['days']?></td>
							<td><?php echo "<label style = 'color:#ff0000;'>".$fetch['checkout']."</label>"."Uhrzeit "."<label>".date("h:i A", strtotime($fetch['checkout_time']))."</label>"?></td>
							<td><?php echo $fetch['status']?></td>
							<td><?php if($fetch['extra_bed'] == "0"){ echo "None";}else{echo $fetch['extra_bed'];}?></td>
							<td><?php echo $fetch['bill'].".00"?></td>
							<td><label class = "" style = "color:#00ff00;">Bezahlt</label></td>
						</tr>
						<!-- end row -->
						<?php
							}
						?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
	<br />
	<br />
	<div style = "text-align:left; margin-right:10px;" class = "navbar navbar-default navbar-fixed-bottom">
		<label> </label>
	</div>
</body>
<script src = "../js/jquery.js"></script>
<script src = "../js/bootstrap.js"></script>
<script src = "../js/jquery.dataTables.js"></script>
<script src = "../js/dataTables.bootstrap.js"></script>
<script type = "text/javascript">
	$(document).ready(function(){
		$("#table").DataTable();
	});
</script>
</html>


