<?php
	require_once 'connect.php';
	// If the information is posted by clicking the add_form button for this file

	if(ISSET($_POST['add_form'])){
		// get posted data
		$room_no = $_POST['room_no'];
		$days = $_POST['days'];
		$extra_bed = $_POST['extra_bed'];
		// Check that the room number sent has not been reserve before (`status` = 'Check In').
		$query = $conn->query("SELECT * FROM `transaction` WHERE `room_no` = '$room_no' && `status` = 'Check In'") or die(mysqli_error($conn));
		$row = $query->num_rows;
        // date_default_timezone_set("Europe/Vienna");
		// $time = date("H:i A", strtotime("+24 HOURS"));


		// if not zero. show a message. room is reserved

		if($row > 0){
			echo "<script>alert('Zimmer ist voll')</script>";
		}else{
			// Because the number of days and the number of beds may have changed, we extract the room reservation price and affect the number of beds and days.
			$query2 = $conn->query("SELECT * FROM `transaction` NATURAL JOIN `guest` NATURAL JOIN `room` WHERE `transaction_id` = '$_REQUEST[transaction_id]'") or die(mysqli_error($conn));
			$fetch2 = $query2->fetch_array();
			$total = $fetch2['price'] * $days;
			$total2 = 800 * $extra_bed;
			$total3 = $total + $total2;
			//$checkout = $fetch['checkout'];
			// update reservatin data
			$conn->query("UPDATE `transaction` SET `room_no` = '$room_no', `days` = '$days', `extra_bed` = '$extra_bed', `status` = 'Check In', `bill` = '$total3' WHERE `transaction_id` = '$_REQUEST[transaction_id]'") or die(mysqli_error($conn));
			header("location:checkin.php");
		}
	}
?>
