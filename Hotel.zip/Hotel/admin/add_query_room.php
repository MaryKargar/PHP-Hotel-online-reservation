<?php
	// If the information is posted by clicking the add_room button for this file

	if(ISSET($_POST['add_room'])){
	// get posted data
		$room_type = $_POST['room_type'];
		$price = $_POST['price'];
		// In addition to textual information, an image file is also posted here. Image information is contained within a global array (for PHP) called $_FILES, and we can access information such as its name and size
		// The addslashes() function returns a string with backslashes in front of predefined characters.
		$photo = addslashes(file_get_contents($_FILES['photo']['tmp_name']));
		$photo_name = addslashes($_FILES['photo']['name']);
		$photo_size = getimagesize($_FILES['photo']['tmp_name']);
		// move_uploaded_file function upload image to photo folder
		move_uploaded_file($_FILES['photo']['tmp_name'],"../photo/" . $_FILES['photo']['name']);
		// save room information in room table
		$conn->query("INSERT INTO `room` (room_type, price, photo) VALUES('$room_type', '$price', '$photo_name')") or die(mysqli_error());
		header("location:room.php");
	}
?>
