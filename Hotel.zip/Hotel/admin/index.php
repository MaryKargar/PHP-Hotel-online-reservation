<!DOCTYPE html>
<?php require_once "connect.php"?>
<html lang = "en">
	<head>
		<title>Online Reservation Hotel</title>
		<meta charset = "utf-8" />
		<meta name = "viewport" content = "width=device-width, initial-scale=1.0" />
		<link rel = "stylesheet" type = "text/css" href = "../css/bootstrap.css " />
		<link rel = "stylesheet" type = "text/css" href = "../css/style.css" />
		<link rel="stylesheet" type="text/css" href="../css/mystyle.css">
	</head>
<body>
	<nav style = "background-color:rgba(0, 0, 0, 0.1);" class = "navbar navbar-default">
		<div  class = "container-fluid">
			<div class = "navbar-header" style ="margin-left:550px">
				<a class = "navbar-brand"  style="font-family: 'Amin';font-size: 25px;" >Online Reservation Hotel</a>
			</div>
		</div>
	</nav>
    
	<div class="container">
		<div class="row">
			<div class="col-md-2"></div>
			<div class="col-md-8">
				
				<ul id = "menu"  style="font-family: 'Amin';" >

				<li><a href = "../index.php">Erste Seite</a></li>  |
				<li><a href = "../reservation.php">Reservation</a></li>  |
				<li><a href = "../dineandlounge.php">Speisekarte</a></li>  |
				<li><a href = "../gallery.php">Gallery</a></li>  |
				<li><a href = "../rulesandregulation.php">Datenschutz</a></li>  |
				<li><a href = "../aboutus.php">Über uns</a></li>  |
				<li><a href = "../contactus.php">Kontakt</a></li>  |
				<li><a href = "index.php">Verwaltung</a></li>

				</ul>
			</div>
			<div class="col-md-2 "></div>

	</div>


	<div class = "container">
		<br />
		<br />
		<div class = "col-md-4"></div>
		<div class = "col-md-4" style="font-family: 'Amin'" dir="ltr">
		<!-- create a box for login foem -->
			<div class = "panel panel-danger">
				<div class = "panel-heading">
				<!-- title -->
					<h4>Verwaltung </h4>
				</div>
				<div class = "panel-body">
				<!-- create form for post data to login.php -->
					<form method = "POST">
					<!-- put username and label in a form group for that placed side by side  -->
						<div class = "form-group">
						
							<label>Benutzer konto</label>
							<input type = "text" name = "username" class = "form-control" required = "required" />
						</div>
						<!-- end form group -->
						<!-- start form group -->
						<div class = "form-group">
							<label>Kennwort</label>
							<input type = "password" name = "password" class = "form-control" required = "required" />
						</div>
						<!-- end form group -->
						<br />

						<!-- form button -->
						<div class = "form-group" >
							<button name = "login" class = "form-control btn btn-primary" ><span style="font-family: 'Amin'">Anmelden</span></button>
						</div>
						
					</form>
				<!-- end form -->
				<!-- attach login.php -->
					<?php require_once 'login.php'?>
				</div>
			</div>
		</div>
		<div class = "col-md-4"></div>
	</div>
	<br />
	<br />
	<div style = "text-align:left; margin-right:10px;" class = "navbar navbar-default navbar-fixed-bottom">
		<label> </label>
	</div>
</body>
<script src = "../js/jquery.js"></script>
<script src = "../js/bootstrap.js"></script>
</html>


