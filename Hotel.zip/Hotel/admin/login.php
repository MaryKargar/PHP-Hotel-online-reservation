<?php
// If the data is posted from login form
	if(ISSET ($_POST['login'])){
		// get username and password that user typed in the login form
		$username = $_POST['username'];
		$password = $_POST['password'];
		// check admin table in database and return data if user exist
		$query = $conn->query("SELECT * FROM `admin` WHERE `username` = '$username' && `password` = '$password'") or die(mysqli_error());
		$fetch = $query->fetch_array();
		// number of row that found in database. if user exist this is >0
		$row = $query->num_rows;
		
		// if user exist
		if($row > 0){
			// In order to find out on other pages of the website, the user is logged in, start a session for save user id. 
			session_start();
			$_SESSION['admin_id'] = $fetch['admin_id'];
			// open header.php (admin home page)
			header('location:home.php');
		}else{
			// if user  not exist. show a message
			echo "<center><labe style = 'color:red;'>Invalid username or password</label></center>";
		}
	}
?>