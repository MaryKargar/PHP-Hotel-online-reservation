<?php 
// start a session and check user id save inside it
	session_start();
	// if user id not exist in session go to index.php and dont allow access admin home page
	if(!ISSET($_SESSION['admin_id'])){
		header("location:index.php");
	}