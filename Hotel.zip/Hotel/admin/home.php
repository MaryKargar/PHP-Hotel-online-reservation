<!DOCTYPE html>
<?php
	// import validate.php and name.php
	// validate.php checks that the user is logged in
	// name.php fetch user name from database
	require_once 'validate.php';
	require 'name.php';
?>
<html lang = "en">
	<head>
		<title>Online Reservation Hotel</title>
		<meta charset = "utf-8" />
		<meta name = "viewport" content = "width=device-width, initial-scale=1.0" />
		<link rel = "stylesheet" type = "text/css" href = "../css/bootstrap.css " />
		<link rel = "stylesheet" type = "text/css" href = "../css/style.css" />
		<link rel="stylesheet" type="text/css" href="../css/mystyle.css">
	</head>
<body>
<!-- site header -->
	<nav style = "background-color:rgba(0, 0, 0, 0.1);" class = "navbar navbar-default">
		<div  class = "container-fluid">
			<div class = "navbar-header" style ="margin-left:550px">
				<a class = "navbar-brand" style="font-family: 'Amin';font-size: 25px;" >Online Reservation Hotel</a>
			</div>
			<ul class = "nav navbar-nav pull-right ">
				<li class = "dropdown">
					<a class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> <?php echo $name;?></a>
					<ul class="dropdown-menu">
						<li><a href="logout.php"><i class = "glyphicon glyphicon-off"></i> Logout</a></li>
					</ul>
				</li>
			</ul>
		</div>
	</nav>
<!-- site header -->

<!-- create admin page menu -->
	<div class = "container-fluid" >
		<div class="row">
		<div class="col-md-3"></div>

		<div class="col-md-6">
			<ul class = "nav nav-pills" style="font-family: 'Amin';font-size: 18px;" >
			
				<li class = "active"><a href = "../index.php">Erste Seite</a></li>	
				<li><a href = "account.php">Benutzer konto</a></li>
				<li><a href = "room.php">Zimmer verwaltung</a></li>
				<li><a href = "reserve.php">Reservation</a></li>
						
			</ul>

		
		</div>

		<div class="col-md-3"></div>
		
		</div>
		
	</div>
<!-- create admin page menu -->
<!-- enter row -->
	<br />
	<!-- create content box -->
	<div class = "container-fluid">
		<div class = "panel panel-default">
			<div class = "panel-body">
			<!-- hotel image in admin page -->
				<center><img src = "../images/back.jpg" width="800px" heigh="600px" /></center>
			</div>
		</div>
	</div>
	<!-- end content box -->
	<br />
	<br />
	<div style = "text-align:left; margin-right:10px;" class = "navbar navbar-default navbar-fixed-bottom">
		<label> </label>
	</div>
</body>
<script src = "../js/jquery.js"></script>
<script src = "../js/bootstrap.js"></script>
</html>


